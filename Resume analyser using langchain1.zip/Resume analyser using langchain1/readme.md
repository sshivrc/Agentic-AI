#### create virtual environment

python -m venv .venv

venv\Scripts\activate

### install packages

pip install -r requirements.txt


#### run the code

python streamlit run app.py

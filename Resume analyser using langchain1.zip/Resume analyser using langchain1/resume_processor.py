import os
from dotenv import load_dotenv

## import libraries
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_chroma import Chroma


# load environ variables
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    raise ValueError("GOOGLE_API_KEY not found in environment variables. Check your .env file.")
os.environ["GOOGLE_API_KEY"] = api_key

## Embedding model
embedding_model = GoogleGenerativeAIEmbeddings(model="text-embedding-004")
## LLM model
llm_model = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.3, max_output_tokens=1024)


## loaders for different file types
def load_resume(file_path):
    if file_path.lower().endswith(".pdf"):
        loader = PyPDFLoader(file_path)
    elif file_path.lower().endswith(".docx"):
        loader = Docx2txtLoader(file_path)
    elif file_path.lower().endswith(".txt"):
        loader = TextLoader(file_path, "utf-8")
    else:
        raise ValueError("Unsupported file format. Please provide a PDF, DOCX, or TXT file.")
    return loader.load()


def resume_analyse(doc, job_description):
    ## chunking the documents
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunks = text_splitter.split_documents(doc)

    full_analysis = ''

    for chunk in chunks:
        prompt = f"""
You are a resume screener. You have to analyze the resume and provide a detailed analysis of the candidate's skills, experience, and qualifications based on the job description provided.
1. Suitability score (0-10)
2. Key skills and experience relevant to the job description
3. Areas of improvement or gaps in skills/experience
4. Overall recommendation (e.g., Strongly Recommend, Recommend, Neutral, Not Recommend)
Job Description: {job_description}
Resume Chunk: {chunk.page_content}
"""
        response = llm_model.invoke(prompt)
        full_analysis += response.content + "\n\n"

    return full_analysis


## store to vector database
def store_to_vectorstore(docs, persist_directory="chroma_store"):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunks = text_splitter.split_documents(docs)

    texts = [chunk.page_content for chunk in chunks]
    metadatas = [{"source": f"resume_chunk_{i}"} for i in range(len(texts))]

    vectorstore = Chroma.from_texts(
        texts=texts,
        metadatas=metadatas,
        embedding=embedding_model,
        persist_directory=persist_directory
    )
    # No need to call .persist() — langchain_chroma persists automatically
    # when persist_directory is set.
    return vectorstore


## smart query function to retrieve relevant chunks from the vector store.
def run_self_query(query, persist_directory="chroma_store"):
    vectorstore = Chroma(persist_directory=persist_directory,
                          embedding_function=embedding_model)

    retriever = vectorstore.as_retriever(
        search_type="mmr",
        search_kwargs={"k": 3}
    )
    docs = retriever.invoke(query)

    ## safe extraction of content from docs
    combined_doc = "\n\n".join([
        d.page_content if hasattr(d, 'page_content') else str(d)
        for d in docs
    ])

    prompt = f"""
You are a resume screener. You have to analyze the resume and provide a detailed analysis of the candidate's skills, experience, and qualifications based on the job description provided.

query: {query}
Resume: {combined_doc}
"""
    response = llm_model.invoke(prompt)
    return response.content.strip()
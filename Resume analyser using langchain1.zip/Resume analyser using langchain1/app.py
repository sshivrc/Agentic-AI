import streamlit as st
from resume_processor import load_resume, resume_analyse, store_to_vectorstore, run_self_query

st.set_page_config(page_title="Resume Screener", page_icon=":guardsman:", layout="wide")
st.title("Resume Screener Application")
st.markdown("Upload a resume and a job description to analyze the candidate's suitability for the role.")

job_description = st.text_area("Enter Job Description", height=200)
uploaded_file = st.file_uploader("Upload Resume (PDF, DOCX, TXT)", type=["pdf", "docx", "txt"])

if st.button("Analyze Resume") and job_description and uploaded_file:
    with open(uploaded_file.name, "wb") as f:
        f.write(uploaded_file.getbuffer())

    with st.spinner("Processing Resume..."):
        docs=load_resume(uploaded_file.name)
        analysis = resume_analyse(docs, job_description)
        store_to_vectorstore(docs)
        st.success("Resume analysis completed and stored in vector database.")
        st.subheader("Resume Analysis")

        st.write("### Analysis Result:")
        st.write(analysis)
        st.download_button("Download Analysis", data=analysis, file_name="resume_analysis.txt", mime="text/plain")

st.divider()
st.subheader("Query the Vector Store")
query = st.text_input("Enter your query to retrieve relevant resume chunks:")
if st.button("Run Query") and query:
    with st.spinner("Running Query..."):
        answer= run_self_query(query)
        if answer:
            if isinstance(answer, str):
                st.write(answer.strip())
            else:
                for i,doc in enumerate(answer,1):
                    st.markdown(f"### Result {i}:")
                    st.write(doc.page_content.strip() if hasattr(doc, 'page_content') else str(doc).strip())
